package prog02;

/**
 * A program to query and modify the phone directory stored in csc220.txt.
 * @author vjm
 */
public class Main {

	/** Processes user's commands on a phone directory.
      @param fn The file containing the phone directory.
      @param ui The UserInterface object to use
      to talk to the user.
      @param pd The PhoneDirectory object to use
      to process the phone directory.
	 */
	public static void processCommands(String fn, UserInterface ui, PhoneDirectory pd) {
		pd.loadData(fn);

		String[] commands = {
				"Add/Change Entry",
				"Look Up Entry",
				"Remove Entry",
				"Save Directory",
		"Exit"};

		String name = null, number = null, oldNumber;
	

		while (true) {
			int c = ui.getCommand(commands);
			switch (c) {
			case -1:
				ui.sendMessage("You shut down the program, restarting.  Use Exit to exit.");
				break;
			case 0:
				name = ui.getInfo(" Add Entry for this Name ");
				number = ui.getInfo(" Enter Number ");
				pd.addOrChangeEntry(name, number);
				  if (name == null)
			           break;
			        if (name.length() == 0) {
			           ui.sendMessage("Blank is not allowed.");
			           break;
			        }
				break;
			case 1:
				name = ui.getInfo(" Enter Name ");
				number = pd.lookupEntry(name);
				  if (name == null)
			           break;
			        if (name.length() == 0) {
			           ui.sendMessage("Blank is not allowed.");
			           break;
			        }
				  if (number == null) 
					  break;
			             System.out.println("\nNo number currently exists for name in the directory.");
				  ui.sendMessage(name + " has " + number);
				break;
			case 2:
				name = ui.getInfo(" Delete the Entry for this Name: ");
				number = pd.removeEntry(name);
				if (name == null)
		            return;
				if (number == null)
		             System.out.println("There is not entry for " + name);
		        else {
		             pd.removeEntry(name);
				ui.sendMessage(" Entry has been removed");
				break;
		        }
			case 3:
				pd.save();
				ui.sendMessage("Directory has been saved");
				break;
			case 4:
				return;
			}
		}
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		String fn = "csc220.txt";
		PhoneDirectory pd = new ArrayBasedPD();
		UserInterface ui = new TestUI();
		processCommands(fn, ui, pd);
	}
}

package prog03;
import prog02.UserInterface;
import prog02.GUI;


/**
 *
 * @author vjm
 */
public class Main {
  private static final String time3 = null;
/** Use this variable to store the result of each call to fib. */
  public static double fibn;

  /** Determine the average time in microseconds it takes to calculate
      the n'th Fibonacci number.
      @param fib an object that implements the Fib interface
      @param n the index of the Fibonacci number to calculate
      @param ncalls the number of calls to average over
      @return the average time per call
  */
  public static double averageTime (Fib fib, int n, int ncalls) {
    // Get the current time in nanoseconds.
    // Call fib(n) ncalls times (needs a loop!).
	  
    long start = System.nanoTime();

    for (int i = 0; i < ncalls; i++)
      fibn = fib.fib(n);

    long end = System.nanoTime();

    return (end - start) / 1000.0 / ncalls;
  }

    

  /** Determine the time in microseconds it takes to to calculate the
      n'th Fibonacci number.  Average over enough calls for a total
      time of at least one second.
      @param fib an object that implements the Fib interface
      @param n the index of the Fibonacci number to calculate
      @return the time it it takes to compute the n'th Fibonacci number
  */
  public static double accurateTime (Fib fib, int n) {
    // Get the time in microseconds using the time method above.
    double t = averageTime(fib, n, 1);
    if (t == 1)
    	return t;
     	
    // If the time is (equivalent to) more than a second, return it.
    // Estimate the number of calls that would add up to one second.
    // Use   (int)(YOUR EXPESSION)   so you can save it into an int variable.
    int numcalls = (int) ((1000000)/t);


    // Get the average time using averageTime above and that many
    // calls and return it.
    return averageTime(fib, n, numcalls);
  }

  private static UserInterface ui = new GUI("Fibonacci experiments");
private static String[] commands;
  
  public static void doExperiments () {
		commands = new String[] {
				"ExponentialFib",
				"LinearFib",
				"LogFib",
				"ConstantFib",
				"MysteryFib",
		"EXIT"};

}

  public static void doExperiments (Fib fib) {
    System.out.println("doExperiments " + fib);
    // EXERCISES 8 and 9


	String n = null, number = null, oldNumber;

	while (true) {
		int n1 = ui.getCommand(commands);
		switch (n1) {
		case 0:
			number = ui.getInfo(" Enter n ");
			Integer result = null;
			try {
			    result = Integer.valueOf(n1);
			} catch (NumberFormatException e) {}
			if (result != null) {
			}
			break;
		case 1:
			number = ui.getInfo(" Enter n ");
			Integer result1 = null;
			try {
			    result1 = Integer.valueOf(n1);
			} catch (NumberFormatException e) {}
			if (result1 != null) {
			}
			break;		
		case 2:
			number = ui.getInfo(" Enter n ");
			Integer result2 = null;
			try {
			    result2 = Integer.valueOf(n1);
			} catch (NumberFormatException e) {}
			if (result2 != null) {
			}
			break;
		case 3:
			number = ui.getInfo(" Enter n ");
			Integer result3 = null;
			try {
			    result3 = Integer.valueOf(n1);
			} catch (NumberFormatException e) {}
			if (result3 != null) {
			}
			break;
		case 4:
			number = ui.getInfo(" Enter n ");
			Integer result4 = null;
			try {
			    result4 = Integer.valueOf(n1);
			} catch (NumberFormatException e) {}
			if (result4 != null) {
			}
			break;
		case 5:
			return;
		} 
	}
}

  

  static void labExperiments () {
    // Create (Exponential time) Fib object and test it.
    Fib efib = new ExponentialFib();
    System.out.println(efib);
    for (int i = 0; i < 11; i++)
      System.out.println(i + " " + efib.fib(i));
    
    // Determine running time for n1 = 1000 and print it out.
    int n1 = 20;
    double time1 = averageTime(efib, n1, 1000);
    System.out.println("n1 " + n1 + " time1 " + time1);
    
    // Calculate constant:  time = constant times O(n).
    double c = time1 / efib.O(n1);
    System.out.println("c " + c);
    
    // Estimate running time for n2=30.
    int n2 = 30;
    double time2test = c * efib.O(n2);
    System.out.println("n2 " + n2 + " estimated time " + time2test);
    
    // Calculate actual running time for n2=30.
    double time2 = averageTime(efib, n2, 10);
    System.out.println("n2 " + n2 + " actual time " + time2);
    
    // Estimate running time for fib(100)
    int n3 = 100;
    double time3test = c * efib.O(n3); String c1 = null;
    System.out.println("c " + c1);
   
  }

  private static void fib(int i) {
	// TODO Auto-generated method stub
	
}

//insert some code here
  // calculating ncalls = ?
  // call averageTime() with ncalls
  // print the results
  // call accurateTime()
  // print the results
  
  /**
   * @param args the command line arguments
   */
  public static void main (String[] args) {
    labExperiments();
    // doExperiments(new ExponentialFib());
    // doExperiments();
    
  }
}

package prog04;

import java.io.*;

import prog02.PhoneDirectory;
import prog02.UserInterface;

/**
 * This is an implementation of PhoneDirectory that uses a sorted
 * array to store the entries.
 * @author vjm
 */
public class SortedDLLPD extends DLLBasedPD {
	public static void processCommands(String fn, UserInterface ui, PhoneDirectory pd) {
		pd.loadData(fn);

		String[] commands = {
				"Add/Change Entry",
				"Look Up Entry",
				"Remove Entry",
				"Save Directory",
		"Exit"};

		String name = null, number = null, oldNumber;
	

		while (true) {
			int c = ui.getCommand(commands);
			switch (c) {
			case -1:
				ui.sendMessage("You shut down the program, restarting.  Use Exit to exit.");
				break;
			case 0:
				name = ui.getInfo(" Add Entry for this Name ");
				number = ui.getInfo(" Enter Number ");
				pd.addOrChangeEntry(name, number);
				  if (name == null)
			           break;
			        if (name.length() == 0) {
			           ui.sendMessage("Blank is not allowed.");
			           break;
			        }
				break;
			case 1:
				name = ui.getInfo(" Enter Name ");
				number = pd.lookupEntry(name);
				  if (name == null)
			           break;
			        if (name.length() == 0) {
			           ui.sendMessage("Blank is not allowed.");
			           break;
			        }
				  if (number == null) 
					  break;
			             System.out.println("\nNo number currently exists for name in the directory.");
				  ui.sendMessage(name + " has " + number);
				break;
			case 2:
				name = ui.getInfo(" Delete the Entry for this Name: ");
				number = pd.removeEntry(name);
				if (name == null)
		            return;
				if (number == null)
		             System.out.println("There is not entry for " + name);
		        else {
		             pd.removeEntry(name);
				ui.sendMessage(" Entry has been removed");
				break;
		        }
			case 3:
				pd.save();
				ui.sendMessage("Directory has been saved");
				break;
			case 4:
				return;
			}
		}
	}


}

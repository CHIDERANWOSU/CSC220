package prog05;

import java.util.Queue;
import java.util.Stack;
import prog02.UserInterface;
import prog02.GUI;

public class Tower {
  private static final String n = null;
static UserInterface ui = new GUI("Towers of Hanoi");

  static public void main (String[] args) {
    int n = getInt("How many disks?");
    if (n <= 0)
      return;
    Tower tower = new Tower(n);

    String[] commands = { "Human plays.", "Computer plays." };
    int c = ui.getCommand(commands);
    if (c == -1)
      return;
    if (c == 0)
      tower.play();
    else
      tower.solve(c, null, null);
  }

  /** Get an integer from the user using prompt as the request.
   *  Return 0 if user cancels.  */
  static int getInt (String prompt) {
    while (true) {
      String number = ui.getInfo(prompt);
      if (number == null)
        return 0;
      try {
        return Integer.parseInt(number);
      } catch (Exception e) {
        ui.sendMessage(number + " is not a number.  Try again.");
      }
    }
  }

  int nDisks;
  StackInt<Integer>[] pegs = (StackInt<Integer>[]) new ArrayStack[3];
private static Object auxiliary;
private Object start;
private Object end;

  Tower (int nDisks) {
    this.nDisks = nDisks;
    for (int i = 0; i < pegs.length; i++)
      pegs[i] = new ArrayStack<Integer>();

    // EXERCISE: Initialize game with pile of nDisks disks on peg 'a' (pegs[0]).


  }

  void play () {
    String[] moves = { "ab", "ac", "ba", "bc", "ca", "cb" };

    while (/* EXERCISE:  player has not moved all the disks to 'c'. */ 
           true /* Not right. */

           ) {
      displayPegs();
      int imove = ui.getCommand(moves);
      if (imove == -1)
        return;
      String move = moves[imove];
      int from = move.charAt(0) - 'a';
      int to = move.charAt(1) - 'a';
      move(from, to, to, move, move, move);
    }
  }

  String stackToString (StackInt<Integer> peg) {
    StackInt<Integer> helper = new ArrayStack<Integer>();

    // String to append items to.
    String s = "";
	return s; }

    // EXERCISE:  append the items in peg to s from bottom to top.

    String queueToString (Queue<String> queue) {
    	String all = "";

    	for (String s : queue)
    	all = all + s + " ";

    return all;
  }

  void displayPegs () {
    String s = "";
    for (int i = 0; i < pegs.length; i++) {
      char abc = (char) ('a' + i);
      s = s + abc + stackToString(pegs[i]);
      if (i < pegs.length-1)
        s = s + "\n";
    }
    ui.sendMessage(s);
  }

  void move (int from, int to, int n, String start, String auxiliary, String end) {
    // EXERCISE:  move one disk form pegs[from] to pegs[to].
    // Don't allow illegal moves:  send a warning message instead.
    // For example "Cannot place disk 2 on top of disk 1."
    // Use ui.sendMessage() to send messages.

	 
		  if (n == 1) {
		 
		   // When n==1, it means we are left with only one disk, so directly move it from source to destination.
		   System.out.println(start + " -> " + end); 
		 
		  } else {
		 
		   move(nDisks - 1, n, n, start, end, auxiliary);    
		 
		   System.out.println(start + " -> " + end);  
		 
		   move(nDisks - 1, n, n, auxiliary, start, end); 
		  }

  }

  private void Tower(int i, char from_pegs, char aux_pegs, char to_pegs) {
	// TODO Auto-generated method stub
	
}

// EXERCISE:  create Goal class.
  class Goal {
    // Data.

	  (int n, start, end, auxiliary) {
		  if (n == 0) return;          
		  Goal(n -1, start, auxiliary, end); 
		  Tower.this.move(start, end, auxiliary, null, null, null);           
		  Goal(n -1, auxiliary, end, start);
	  }
	  
	  static int counter;
	  static Peg start;
	  static Peg goal;
	  static Peg temp;
	  
	  void move(start, end) {
		    System.out.println(counter + ": Move " + start + " to " + end);
		    counter++;
		  }


    // Constructor.

      public String toString () {
      String[] pegNames = { "a", "b", "c" };
      String s = "";










      return s;
    }

	private void Goal(int i, int start2, int auxiliary2, int end2) {
		// TODO Auto-generated method stub
		
	}
  }
  


  // EXERCISE:  display contents of a stack of goals

  void print_game_state(StackInt a, StackInt b, StackInt c) {
}

  
  void solve (int i, String n2, String n3) {
    // EXERCISE
	   int move = 0;
		     move++; 
		     solve(move, n3, n3);
		} }
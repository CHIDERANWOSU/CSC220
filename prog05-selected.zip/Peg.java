package prog05;

public class Peg {

	  int pegNum;
	  
	  Peg(int value) {
	    pegNum = value;
	  }

	  // Override Object.toString
	  public String toString() {
	    return Integer.toString(pegNum);
	  }
	}
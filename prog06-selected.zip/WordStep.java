package prog06;

import java.util.*;
import java.io.*;
import prog02.GUI;
import prog02.UserInterface;



public class WordStep {

 static UserInterface ui = new GUI("WordStep");

 //static UserInterface ui = new TestUI("WordStep");

 static ArrayList < String > words = new ArrayList < String > ();



 public static void main(String args[]) {



  WordStep game = new WordStep();

  String fileName = ui.getInfo("Name of word file: ");

  game.loadWords(fileName);



  String start = ui.getInfo("Starting word: ");

  if (start == null)

   return;

  if (find(start) == -1)

   ui.sendMessage("word is not in Dictionary");



  String target = ui.getInfo("Target word: ");

  if (start == null)

   return;

  if (find(start) == -1) {

   ui.sendMessage("word is not in Dictionary");

   return;

  }





  String[] commands = {

   "Human plays.",

   "Computer plays."

  };

  int c = ui.getCommand(commands);



  switch (c) {

   case 0:

    game.play(start, target);

    break;

   case 1:

    game.solve(start, target);

    break;

  }

 }





 public void play(String start, String target) {

  while (true) {

   String first = start;



   ui.sendMessage("Current word: " + start + "\nTarget word: " + target);

   start = ui.getInfo("What is your next word?");



   if (start == null)

    System.exit(0);



   else if (start.compareTo(target) == 0) {

    ui.sendMessage("You win!");

    System.exit(0);

   } else if (find(start) == -1) {

    ui.sendMessage("This word is not in the dictionary.");

    play(first, target);

   } else if (offBy1(start, first) == false) {

    ui.sendMessage("Sorry, but " + start + " does not differ from " + first + " by one letter.");

    play(first, target);

   } else {

    play(start, target);

   }





  }





 }





 public void solve(String start, String target) {

  int[] parents = new int[words.size()];

  Arrays.fill(parents, -1);



  ArrayQueue < Integer > queue = new ArrayQueue < Integer > ();



  queue.offer(find(start));

  String current;



  while (!queue.isEmpty()) {

   current = words.get(queue.poll());



   for (int i = 0; i < words.size(); i++) {

    if (start.compareToIgnoreCase(words.get(i)) != 0 && offBy1(words.get(i), current) && parents[i] == -1) {

     if (current.compareToIgnoreCase(target) == 0) {

      ui.sendMessage("Got to " + current + " from " + start + ".");



      String answers = current;



      int v = find(current);



      while (parents[v] != -1) {



       int next = parents[v];

       answers = words.get(next) + "\n" + answers;

       v = next;



      }

      ui.sendMessage(answers);

      break;



     } else {

      if (target.compareTo(current) == 0)

       queue.offer(i);

      else {

       queue.offer(i);

       parents[i] = find(current);

      }

     }

    }

   }

  }

 }





 public static boolean offBy1(String start, String check) {

  if (start.compareTo(check) == 0)

   return false;

  if (start.length() != check.length()) {

   return false;

  }



  int k = 0;

  for (int i = 0; i < start.length(); i++) {

   if (start.charAt(i) != check.charAt(i)) {

    k++;

   }

  }



  if (k == 1)

   return true;

  else

   return false;

 }



 public void loadWords(String fileName) {

  File dict = new File(fileName);

  try {

   Scanner input = new Scanner(dict);

   while (input.hasNext()) {

    words.add(input.next());

   }

  } catch (FileNotFoundException h) {

   ui.sendMessage("File not found");

   System.exit(0);

  }

 }



 public static int find(String word) {

  for (int k = 0; k < words.size(); k++) {

   if (word.compareTo(words.get(k)) == 0) {

    return k;

   }

  }

  return -1;

 }

}